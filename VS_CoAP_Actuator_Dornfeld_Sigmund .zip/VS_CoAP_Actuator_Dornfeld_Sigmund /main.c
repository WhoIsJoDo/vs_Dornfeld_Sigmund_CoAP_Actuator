//Von Benjamin Sigmund und Joshua Dornfeld
//Projekt: CoAP Actuator


//*************Multiple Choice 1**********************//
//Füge hier deine ausgewählte Antwort ein

//****************************************************//


#include <stdbool.h>  // Einbinden der Standard-Boolean-Definitionen
#include <stdint.h>  // Einbinden der Standard-Integer-Typ-Definitionen
#include <string.h>  // Einbinden der Standard-String-Manipulationsfunktionen
#include <stdio.h>  // Einbinden der Standard-Eingabe/Ausgabe-Funktionen

#include "inc/hw_ints.h"  // Einbinden der Hardware-Interrupt-Definitionen
#include "inc/hw_memmap.h"  // Einbinden der Hardware-Speicherabbild-Definitionen
#include "inc/hw_nvic.h"  // Einbinden der Hardware-NVIC-Definitionen
#include "inc/hw_types.h"  // Einbinden der Hardware-Typ-Definitionen
#include "driverlib/flash.h"  // Einbinden der Treiberbibliothek für Flash-Speicher
#include "driverlib/gpio.h"  // Einbinden der Treiberbibliothek für GPIO (General Purpose Input/Output)
#include "driverlib/interrupt.h"  // Einbinden der Treiberbibliothek für Interrupt-Verarbeitung
#include "driverlib/sysctl.h"  // Einbinden der Treiberbibliothek für Systemsteuerung
#include "driverlib/rom_map.h"  // Einbinden der ROM-Mapping-Treiberbibliothek


//*************Multiple Choice 2**********************//
//Füge hier deine ausgewählte Antwort ein

//****************************************************//


#include "utils/uartstdio.h"  // Einbinden der UART Standard-E/A-Dienstprogramme

#include "userlib/io.h"  // Einbinden der benutzerdefinierten IO-Bibliothek

#include "FreeRTOS.h"  // Einbinden der FreeRTOS-Hauptheaderdatei
#include "task.h"  // Einbinden der FreeRTOS-Task-Headerdatei

#include <inc/hw_gpio.h>
#include <driverlib/sysctl.h>
#include <driverlib/debug.h>
#include <driverlib/pwm.h>
#include <driverlib/pin_map.h>
//******************
#define STEPS         256

#define SYSTICKHZ 100
#define SYSTICKMS (1000 / SYSTICKHZ)

// Definieren der CoAP (Constrained Application Protocol) Codes
#define COAP_CODE_GET 1
#define COAP_CODE_POST 2
#define COAP_CODE_PUT 3
#define COAP_CODE_DELETE 4

uint32_t g_ui32IPAddress;  // Die aktuelle IP-Adresse
int gespielteNote = 0;

struct mg_mgr g_mgr;  // Mongoose-Manager

struct mg_connection *nc;  // Globale Variable für die Mongoose-Verbindung

uint32_t g_ui32SysClock;  // Systemtaktfrequenz


//*************Multiple Choice 3**********************//
//Füge hier deine ausgewählte Antwort ein

//****************************************************//


// Aufgaben-Deklarationen
void vTaskDisplay(void *pvParameters);
void vTaskCoap(void *pvParameters);

// Implementierung von gettimeofday
int gettimeofday(struct timeval *tv, void *tz) {
    if (tv) {
        uint64_t time_ms = SysCtlClockGet() * 1000;  // Systemtakt in Millisekunden
        tv->tv_sec = time_ms / 1000000;  // Umrechnen in Sekunden
        tv->tv_usec = time_ms % 1000000;  // Verbleibende Mikrosekunden
    }
    return 0;
}

// Implementierung von mg_lwip_mgr_schedule_poll als Platzhalter
void mg_lwip_mgr_schedule_poll(struct mg_mgr *mgr) {
    // Leere Platzhalterfunktion
}


// Die Fehler-Routine, die aufgerufen wird, wenn die Treiberbibliothek einen Fehler feststellt.
#ifdef DEBUG
void __error__(char *pcFilename, uint32_t ui32Line) {
    // Fehlerbehandlungsroutine für den Debug-Modus
}
#endif


// Funktion um den Status der Netzwerkverbindung zu überprüfen und auf Änderungen zu reagieren
// Regelmäßiger Aufruf
void lwIPHostTimerHandler(void) {

//*************Multiple Choice 4**********************//
//Füge hier deine ausgewählte Antwort ein

//****************************************************//

    if (ui32NewIPAddress != g_ui32IPAddress) {  // Überprüfen, ob sich die IP-Adresse geändert hat
        if (ui32NewIPAddress == 0xffffffff) {  // Keine Verbindung
            UARTprintf("Waiting for link.\n");
        } else if (ui32NewIPAddress == 0) {  // DHCP-Prozess läuft
            UARTprintf("Waiting for IP address.\n");
        } else {  // Neue IP-Adresse zugewiesen
            UARTprintf("IP Address assigned: %s\n", ipaddr_ntoa((const ip_addr_t *)&ui32NewIPAddress));
        }
        g_ui32IPAddress = ui32NewIPAddress;  // Die neue IP-Adresse speichern
    }

    if ((ui32NewIPAddress == 0) || (ui32NewIPAddress == 0xffffffff)) {  // Keine IP-Adresse
        // Nichts tun und weiter warten
    }
}

//*************Multiple Choice 5**********************//
//Füge hier deine ausgewählte Antwort ein

//****************************************************//

    if (ev == MG_EV_POLL) return;

    switch (ev) {
            case MG_EV_COAP_CON: {
                struct mg_coap_message *cm = (struct mg_coap_message *) ev_data;
                UARTprintf("CON with msg_id = %d received\n", cm->msg_id);
                if (mg_coap_send_ack(nc, cm->msg_id) == 0) {
                    UARTprintf("Successfully sent ACK for message with msg_id = %d\n", cm->msg_id);

                    if (cm->code_class == MG_COAP_CODECLASS_REQUEST) {
                        switch (cm->code_detail) {
                            case COAP_CODE_GET:
                                UARTprintf("Received GET request\n");
                                // GET-Anfrage verarbeiten
                                break;


                            //*************Multiple Choice 6**********************//
                            //Füge hier deine ausgewählte Antwort ein

                            //****************************************************//

                                UARTprintf("Received POST request\n");

                                // POST-Anfrage verarbeiten
                                // Hier extrahieren wir den Payload
                                if (cm->payload.len > 0) {
                                    // Speicher für den Payload reservieren und kopieren
                                    char payload[cm->payload.len + 1];
                                    memcpy(payload, cm->payload.p, cm->payload.len);
                                    payload[cm->payload.len] = '\0'; // Null-terminierten String erstellen

                                    // Extrahiert einen Integer-Wert aus dem Payload
                                    int note = 0;
                                    if (sscanf(payload, "%d", &note) == 1) {
                                        UARTprintf("Received integers: %d \n", note);

                                        // Weiterverarbeitung der Integer-Werte

                                        //Auf globale Variable Übertragen für Display Ausgabe
                                        gespielteNote = note;

                                        // ******************PWM****************

                                        // Definition von Variablen für die PWM-Level der LEDs
                                        volatile uint32_t ui32BlueLevel;
                                        volatile uint32_t ui32RedLevel;
                                        volatile uint32_t ui32GreenLevel;

                                        // Aktivieren des PWM0-Peripheriegeräts
                                        SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);

                                        // Aktivieren des GPIOF-Peripheriegeräts für PWM
                                        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);

                                        // Konfigurieren des GPIO-Pins PF1 als PWM-Ausgang
                                        GPIOPinTypePWM(GPIO_PORTF_BASE,GPIO_PIN_1);
                                        GPIOPinConfigure(GPIO_PF1_M0PWM1);

                                        // Setzen des PWM-Taktes
                                        PWMClockSet(PWM0_BASE,PWM_SYSCLK_DIV_64);


                                        // PWM-Periode konfigurieren
                                        PWMGenConfigure(PWM0_BASE,PWM_GEN_0,PWM_GEN_MODE_DOWN);
                                        PWMGenPeriodSet(PWM0_BASE,PWM_GEN_0,note) ;

                                        // Aktivieren des PWM-Ausgangs
                                        PWMOutputState(PWM0_BASE,PWM_OUT_1_BIT, true);// a starter for the load value
                                        PWMGenEnable(PWM0_BASE, PWM_GEN_0);

                                        // Setzen der Pulsweite
                                        PWMPulseWidthSet(PWM0_BASE, PWM_OUT_1, 200) ;

                                        // PWM für LEDs
                                        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOG);

                                        // Konfigurieren der GPIO-Pins für PWM
                                        GPIOPinTypePWM(GPIO_PORTF_BASE,GPIO_PIN_2);
                                        GPIOPinTypePWM(GPIO_PORTF_BASE,GPIO_PIN_3);
                                        GPIOPinTypePWM(GPIO_PORTG_BASE,GPIO_PIN_0);
                                        GPIOPinConfigure(GPIO_PF2_M0PWM2);
                                        GPIOPinConfigure(GPIO_PF3_M0PWM3);
                                        GPIOPinConfigure(GPIO_PG0_M0PWM4);

                                        // PWM-Konfiguration für die rote LED
                                        PWMGenConfigure(PWM0_BASE,PWM_GEN_1,PWM_GEN_MODE_DOWN) ;
                                        PWMGenPeriodSet(PWM0_BASE,PWM_GEN_1,15000);
                                        PWMOutputState(PWM0_BASE,PWM_OUT_2_BIT, true);

                                        // PWM-Konfiguration für die grüne LED
                                        PWMGenPeriodSet(PWM0_BASE,PWM_GEN_1,1500) ;
                                        PWMOutputState(PWM0_BASE,PWM_OUT_3_BIT, true);
                                        PWMGenEnable(PWM0_BASE, PWM_GEN_1);

                                        // PWM-Konfiguration für die blaue LED
                                        PWMGenConfigure(PWM0_BASE,PWM_GEN_2,PWM_GEN_MODE_DOWN);
                                        PWMGenPeriodSet(PWM0_BASE,PWM_GEN_2,1500) ;
                                        PWMOutputState(PWM0_BASE,PWM_OUT_4_BIT, true);

                                        PWMGenEnable(PWM0_BASE, PWM_GEN_2);

                                        // Setzen der PWM-Pulsweiten für die LEDs
                                        ui32RedLevel =note*2 ;
                                        PWMPulseWidthSet(PWM0_BASE, PWM_OUT_2,ui32RedLevel) ;
                                        ui32GreenLevel =note;
                                        PWMPulseWidthSet(PWM0_BASE, PWM_OUT_3, ui32GreenLevel) ;
                                        ui32BlueLevel = note/2;
                                        PWMPulseWidthSet(PWM0_BASE, PWM_OUT_4, ui32BlueLevel) ;

                                        //*************************************
                                    } else {
                                        UARTprintf("Invalid payload format\n"); // Ungültiger Payload
                                    }
                                } else {
                                    UARTprintf("Empty payload\n");  // Leerer Payload
                                }
                                break;
                            case COAP_CODE_PUT:
                                UARTprintf("Received PUT request\n");
                                // PUT-Anfrage verarbeiten
                                break;
                            case COAP_CODE_DELETE:
                                UARTprintf("Received DELETE request\n");
                                // DELETE-Anfrage verarbeiten
                                break;
                            default:
                                UARTprintf("Unknown CoAP method\n");
                                break;
                        }
                    }
                } else {
                    UARTprintf("Failed to send ACK\n");
                }
                break;
            }
            //Prüfung auf andere CoAP Events
            case MG_EV_COAP_ACK:
            case MG_EV_COAP_RST:
            case MG_EV_COAP_NOC: {
                struct mg_coap_message *cm = (struct mg_coap_message *) ev_data;
                UARTprintf("ACK/RST/NOC with msg_id = %d received\n", cm->msg_id);
                break;
            }
        }
}


//*****************************************************************************
//
// Hauptfunktion
//
//*****************************************************************************
int main(void) {
    uint32_t ui32User0, ui32User1;
    uint8_t pui8MACArray[8];

    SysCtlMOSCConfigSet(SYSCTL_MOSC_HIGHFREQ);  // Hauptoszillator aktivieren

    g_ui32SysClock = MAP_SysCtlClockFreqSet(  // Systemtakt auf 120 MHz setzen
        (SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN | SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480), 120000000);

    io_init();  // Gerät-Pins/IO-Ports initialisieren

    UARTStdioConfig(0, 115200, g_ui32SysClock);  // UART für Debugging konfigurieren

    UARTprintf("\033[2J\033[H");  // Terminal löschen und Banner ausgeben
    UARTprintf("Dornfeld -- Sigmund -- CoAP\n");
    UARTprintf("CoAP Server - FreeRTOS\n\n");

    MAP_FlashUserGet(&ui32User0, &ui32User1);  // MAC-Adresse aus Flash-Speicher abrufen
    if ((ui32User0 == 0xffffffff) || (ui32User1 == 0xffffffff)) {
        UARTprintf("No MAC programmed!\n");  // Überprüfen, ob MAC-Adresse gültig ist
        while (1) {}
    }

    // MAC-Adresse umwandeln und einstellen
    pui8MACArray[0] = ((ui32User0 >> 0) & 0xff);
    pui8MACArray[1] = ((ui32User0 >> 8) & 0xff);
    pui8MACArray[2] = ((ui32User0 >> 16) & 0xff);
    pui8MACArray[3] = ((ui32User1 >> 0) & 0xff);
    pui8MACArray[4] = ((ui32User1 >> 8) & 0xff);
    pui8MACArray[5] = ((ui32User1 >> 16) & 0xff);


    //*************Multiple Choice 7**********************//
    //Füge hier deine ausgewählte Antwort ein

    //****************************************************//


    //*************Multiple Choice 8**********************//
    //Füge hier deine ausgewählte Antwort ein

    //****************************************************//


    xTaskCreate(vTaskDisplay, (const portCHAR *)"displaytask", configMINIMAL_STACK_SIZE, NULL, 1, NULL);  // Display-Task erstellen
    xTaskCreate(vTaskCoap, (const portCHAR *)"coaptask", configMINIMAL_STACK_SIZE, NULL, 1, NULL);  // CoAP-Task erstellen

    vTaskStartScheduler();  // FreeRTOS-Scheduler starten

    while (1) {};  // Ausführung sollte hier nicht ankommen
}

// Task für Anzeige
void vTaskDisplay(void *pvParameters) {
    while (1) {
        io_display(g_ui32IPAddress);  // IP-Adresse anzeigen
        if (gespielteNote != 0){
        io_note_to_display(gespielteNote); // Zuletzt gespielte Note anzeigen
        }
        vTaskDelay(pdMS_TO_TICKS(50));  // Verzögerung um 50 Millisekunden

    }
}
// Task für CoAP
void vTaskCoap(void *pvParameters) {


    //*************Multiple Choice 9**********************//
    //Füge hier deine ausgewählte Antwort ein

    //****************************************************//


    if (nc == NULL) {
        UARTprintf("Unable to start listener at %s\n", s_default_address);  // Überprüfen, ob Bindung erfolgreich ist
        return;
    }

    UARTprintf("Listening for CoAP messages at %s\n", s_default_address);  // Abhörnachricht ausgeben

    //*************Multiple Choice 10**********************//
    //Füge hier deine ausgewählte Antwort ein

    //****************************************************//

    while (1) {

        //*************Multiple Choice 11**********************//
        //Füge hier deine ausgewählte Antwort ein

        //****************************************************//
        vTaskDelay(pdMS_TO_TICKS(50));  // Verzögerung um 50 Millisekunden
    }
}

